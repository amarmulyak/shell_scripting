#!/bin/bash

for COLOR in "Red" "Green" "Blue"
do
	echo "Color: $COLOR"
done
