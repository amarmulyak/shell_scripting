#!/bin/bash

COLORS="Red Green Blue"

for COLOR in $COLORS
do
	echo "$COLOR"
done
