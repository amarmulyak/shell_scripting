#!/bin/bash
HOST_NAME=$(hostname)

echo "I'm working on ${HOST_NAME}"
