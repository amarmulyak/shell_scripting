#!/bin/bash
VAR='hostname'
echo "Scripting is fun! ${VAR}"
